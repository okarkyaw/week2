@extends("layout")
@section('content')
<div class="row">
    <h1 class="col s12">To do Lists</h1>

    <div class="col s8">
        @foreach($todolists as $todolist)
        <div class="card blue-grey darken-1">
            <div class="card-content white-text">
                <span class="card-title">{{$todolist->title}}</span>
                <p>{{$todolist->content}}</p>
            </div>
        </div>
        @endforeach
    </div>
</div>
@endsection