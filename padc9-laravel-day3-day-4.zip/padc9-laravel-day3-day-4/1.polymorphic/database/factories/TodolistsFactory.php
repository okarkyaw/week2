<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\Todolists;
use Faker\Generator as Faker;

$factory->define(Todolists::class, function (Faker $faker) {
    return [
        'title' => $faker->sentence(),
        'content' => $faker->paragraph(),
    ];
});
