<?php

namespace App\Http\Controllers;

use App\Todolists;
use App\Http\Requests\LoginRequest;
use Illuminate\Http\Request;

class TodolistsController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        //  
    }

    /**
     * Show the form for creating a new resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function loginForm()
    {
        return view('customer.login');
    }

    public function login(LoginRequest $request)
    {
        \Auth::guard('customer')->attempt($request->validated());

        if (\Auth::guard('customer')->check()) {
            return redirect(route('todolist.index'));
        } else {
            return "Login Fail";
        }
    }
    public function create()
    {
        return view('todolist.create');
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(TodolistsRequest $request)
    {
        $todolist->title = $request->title;
        $todolist->content = $request->content;
        $todolist->save();
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Todolists  $todolists
     * @return \Illuminate\Http\Response
     */
    public function show(Todolists $todolists)
    {
        $todolists = Todolists::all();
        return view('todolist.index', compact('todolists'));  
    }

    /**
     * Show the form for editing the specified resource.
     *
     * @param  \App\Todolists  $todolists
     * @return \Illuminate\Http\Response
     */
    public function edit(Todolists $todolists)
    {
        //
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Todolists  $todolists
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, Todolists $todolists)
    {
        //
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Todolists  $todolists
     * @return \Illuminate\Http\Response
     */
    public function destroy(Todolists $todolists)
    {
        //
    }
}
